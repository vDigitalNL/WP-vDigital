const yargs = require( 'yargs' ).default( 'env', null );
const argv = require( 'yargs' ).argv;
require( 'dotenv' ).config( { path : yargs.argv.env ? './.env.' + yargs.argv.env : null } );

const aliasify = require( 'aliasify' );
const autoPrefixer = require( 'gulp-autoprefixer' );
const babel = require( 'gulp-babel' );
const babelify = require( 'babelify' );
const browserify = require( 'browserify' );
const cleanCss = require( 'gulp-clean-css' );
const concat = require( 'gulp-concat' );
const footer = require( 'gulp-footer' );
const fs = require( 'fs' );
const gulp = require( 'gulp' );
const gulpIf = require( 'gulp-if' );
const header = require( 'gulp-header' );
const gulpPo2Mo = require( 'gulp-potomo' );
const mediaQueriesSplitter = require( 'gulp-media-queries-splitter' );
const merge = require( 'merge-stream' );
const path = require( 'path' );
const rename = require( 'gulp-rename' );
const sass = require( 'gulp-sass' );
const sassTildeImporter = require( 'node-sass-tilde-importer' );
const sourceMaps = require( 'gulp-sourcemaps' );
const uglify = require( 'gulp-uglify' );
const vinylBuffer = require( 'vinyl-buffer' );
const vinylSource = require( 'vinyl-source-stream' );

const environment = process.env.ENVIRONMENT || 'production';
const isProduction = environment === 'production' || argv.production === true;

const baseThemePath = './wp-content/themes/' + (process.env.BASE_THEME_FOLDER || '[base_theme_folder]');
const childThemePath = './wp-content/themes/' + (process.env.CHILD_THEME_FOLDER || '[child_theme_folder]');

const browserCompatibility = getBrowserCompatibility();
const autoPrefixerOptions = { browsers : browserCompatibility };

// Debug scripts when when SCRIPT_DEBUG is set to TRUE in the .env file (only used when on production)
const debugScripts = (process.env.SCRIPT_DEBUG || 'false').toLowerCase() === 'true';

// Get all the theme modules
const themeModules = getThemeModules();

gulp.task( 'assets:js', function() {
	/*
	 * Define basic config and entry JS files
	 */
	let aliasifyConfig = {
		aliases    : {
			'jquery' : './wp-content/themes/[base_theme_folder]/resources/js/theme/jquery.js'
		}, verbose : debugScripts, global : true
	}, browserifyConfig = {
		debug   : debugScripts,
		noParse : [],
		paths   : [
			childThemePath + '/resources/js/theme',
			childThemePath + '/resources/js',
			baseThemePath + '/resources/js/theme',
			baseThemePath + '/resources/js',
			'./node_modules'
		]
	}, entryScripts = {
		header : [ baseThemePath + '/resources/js/header.js' ],
		footer : [ baseThemePath + '/resources/js/footer.js' ]
	};

	if ( fs.existsSync( childThemePath + '/resources/js/header.js' ) ) {
		entryScripts.header.push( childThemePath + '/resources/js/header.js' );
	}

	if ( fs.existsSync( childThemePath + '/resources/js/footer.js' ) ) {
		entryScripts.footer.push( childThemePath + '/resources/js/footer.js' );
	}

	/*
	 * Search for JS files from theme modules
	 */
	Object.keys( themeModules ).forEach( module => {
		let moduleData = themeModules[module];

		for ( const path of moduleData.paths ) {
			let headerFilename = path + '/resources/js/header.js',
				footerFilename = path + '/resources/js/footer.js';

			if ( fs.existsSync( headerFilename ) ) {
				entryScripts.header.push( headerFilename );
			}

			if ( fs.existsSync( footerFilename ) ) {
				entryScripts.footer.push( footerFilename );
			}
		}
	} );

	/*
	 * Process header JS files
	 */
	merge( gulp.src( [
		'./wp-includes/js/jquery/jquery.js',
		baseThemePath + '/resources/js/functions/**/*.js',
		childThemePath + '/resources/js/functions/**/*.js'
	] ), browserify( browserifyConfig )
		.transform( babelify.configure( {
			presets : [ [ '@babel/env', {
				debug   : false,
				targets : { browsers : browserCompatibility }
			} ] ]
		} ) )
		.transform( aliasify, aliasifyConfig )
		.add( entryScripts.header )
		.bundle()
		.pipe( vinylSource( 'header.js' ) )
		.pipe( vinylBuffer() )
		.pipe( gulpIf( !isProduction, sourceMaps.init() ) )
		.pipe( gulpIf( isProduction, uglify( {
			mangle   : false,
			compress : {
				drop_console : !debugScripts, drop_debugger : !debugScripts
			}
		} ) ) )
		.on( 'error', ( err ) => {
			console.log( 'Error while uglifying header.js', err.toString() );
			this.emit( 'end' );
		} )
		.pipe( gulpIf( !isProduction, sourceMaps.write() ) )
		.pipe( gulp.dest( childThemePath + '/assets/js/build' ) ) )
		.pipe( concat( 'header.js' ) )
		.pipe( gulp.dest( childThemePath + '/assets/js' ) )
		.pipe( gulpIf( isProduction, rename( function( path ) { path.extname = '.min' + path.extname; } ) ) )
		.pipe( gulpIf( isProduction, gulp.dest( childThemePath + '/assets/js' ) ) );

	/*
	 * Process footer JS files
	 */
	browserify( browserifyConfig )
		.transform( babelify.configure( {
			presets : [ [ '@babel/env', {
				debug   : false,
				targets : { browsers : browserCompatibility }
			} ] ]
		} ) )
		.transform( aliasify, aliasifyConfig )
		.add( entryScripts.footer )
		.bundle()
		.pipe( vinylSource( 'footer.js' ) )
		.pipe( vinylBuffer() )
		.pipe( gulpIf( !isProduction, sourceMaps.init() ) )
		.pipe( gulpIf( !isProduction, sourceMaps.write() ) )
		.pipe( gulp.dest( childThemePath + '/assets/js' ) )
		.pipe( gulpIf( isProduction, uglify( {
			mangle   : false,
			compress : {
				drop_console : !debugScripts, drop_debugger : !debugScripts
			}
		} ) ) )
		.on( 'error', ( err ) => {
			console.log( 'Error while uglifying footer.js', err.toString() );
			this.emit( 'end' );
		} )
		.pipe( gulpIf( isProduction, rename( function( path ) { path.extname = '.min' + path.extname; } ) ) )
		.pipe( gulpIf( isProduction, gulp.dest( childThemePath + '/assets/js' ) ) );

	/*
	 * Copy admin scripts
	 */
	gulp.src( [ baseThemePath + '/resources/js/admin/**/*.js', childThemePath + '/resources/js/admin/**/*.js' ] )
		.pipe( babel( {
			presets : [ [ '@babel/env', {
				debug   : false,
				targets : { browsers : browserCompatibility }
			} ] ]
		} ) )
		.pipe( gulpIf( !isProduction, sourceMaps.init() ) )
		.pipe( gulpIf( isProduction, uglify( {
			mangle   : false,
			compress : {
				drop_console : !debugScripts, drop_debugger : !debugScripts
			}
		} ) ) )
		.on( 'error', ( err ) => {
			console.log( 'Error while uglifying admin JS files', err.toString() );
			this.emit( 'end' );
		} )
		.pipe( gulpIf( !isProduction, sourceMaps.write() ) )
		.pipe( gulp.dest( childThemePath + '/assets/js/admin' ) );
} );

gulp.task( 'assets:sass', function() {
	let moduleImports = [];

	/*
	 * Search for Sass files from theme modules
	 */
	Object.keys( themeModules ).forEach( module => {
		let moduleData = themeModules[module];

		for ( const path of moduleData.paths ) {
			let filename = path + '/resources/sass/module.scss';

			try {
				if ( fs.existsSync( filename ) ) {
					moduleImports.push( '@import \'' + filename + '\';' );
				}
			} catch ( error ) {
			}
		}
	} );

	/*
	 * Process front end Sass files
	 */
	gulp.src( baseThemePath + '/resources/sass/main.scss' )
		.pipe( header( '@import \'' + childThemePath + '/resources/sass/source/utils/all.scss' + '\';' ) )
		.pipe( footer( '@import \'' + childThemePath + '/resources/sass/main.scss' + '\';' ) )
		.pipe( footer( moduleImports.join( '\n' ) ) )
		.pipe( gulpIf( !isProduction, sourceMaps.init() ) )
		.pipe( sass( {
			importer    : sassTildeImporter,
			indentWidth : 4,
			outputStyle : 'expanded'
		} ).on( 'error', sass.logError ) )
		.pipe( autoPrefixer( autoPrefixerOptions ) )
		.pipe( mediaQueriesSplitter( [
			{ media : 'all', filename : 'all.css' },
			{ media : [ 'none', { minUntil : '576px' } ], filename : 'main.css' },
			{
				media    : [
					{ min : '576px', minUntil : '768px' },
					{ min : '576px', max : '768px' }
				],
				filename : 'tablet.css'
			},
			{ media : { min : '768px' }, filename : 'desktop.css' }
		] ) )
		.pipe( gulpIf( !isProduction, sourceMaps.write() ) )
		.pipe( gulp.dest( childThemePath + '/assets/css' ) )
		.pipe( gulpIf( isProduction, cleanCss() ) )
		.pipe( gulpIf( isProduction, rename( function( path ) { path.extname = '.min' + path.extname; } ) ) )
		.pipe( gulpIf( isProduction, gulp.dest( childThemePath + '/assets/css' ) ) );

	/*
	 * Process and copy admin Sass files
	 */
	gulp.src( [
		baseThemePath + '/resources/sass/admin/**/*.scss',
		childThemePath + '/resources/sass/admin/main.scss'
	] )
		.pipe( gulpIf( !isProduction, sourceMaps.init() ) )
		.pipe( sass( {
			importer    : sassTildeImporter,
			indentWidth : 4,
			outputStyle : 'expanded'
		} ).on( 'error', sass.logError ) )
		.pipe( autoPrefixer( autoPrefixerOptions ) )
		.pipe( gulpIf( !isProduction, sourceMaps.write() ) )
		.pipe( gulp.dest( childThemePath + '/assets/css/admin' ) )
		.pipe( gulpIf( isProduction, cleanCss() ) )
		.pipe( gulpIf( isProduction, rename( function( path ) { path.extname = '.min' + path.extname; } ) ) )
		.pipe( gulpIf( isProduction, gulp.dest( childThemePath + '/assets/css/admin' ) ) );
} );

gulp.task( 'languages', function() {
	let files = {};
	/*
	 * Search for PO files in the theme modules
	 */
	Object.keys( themeModules ).forEach( module => {
		let moduleData = themeModules[module];

		for ( const path of moduleData.paths ) {
			const filesFromModule = searchDir( path + '/languages/', '.po', true );

			if ( filesFromModule === false ) {
				continue;
			}

			for ( let i = 0; i < filesFromModule.length; i++ ) {
				const filename = './' + filesFromModule[i];
				let languageKey = filename.replace( path + '/languages/', '' );
				languageKey = languageKey.replace( '.po', '' );

				if ( fs.existsSync( filename ) ) {
					if ( files[languageKey] === undefined ) {
						files[languageKey] = [];
					}

					files[languageKey].push( filename );
				}
			}
		}
	} );

	/*
	 * Search Files form languages folder
	 */
	const filesFromLanguagesFolder = searchDir( childThemePath + '/languages/', '.po', false );

	for ( let i = 0; i < filesFromLanguagesFolder.length; i++ ) {
		const filename = './' + filesFromLanguagesFolder[i];
		let languageKey = filename.replace( childThemePath + '/languages/', '' );
		languageKey = languageKey.replace( '.po', '' );

		if ( fs.existsSync( filename ) ) {
			if ( files[languageKey] === undefined ) {
				files[languageKey] = [];
			}

			files[languageKey].push( filename );
		}
	}

	Object.keys( files ).forEach( function( languageKey ) {
		/*
		 * Combine files to one .po file
		 */
		const languageFiles = files[languageKey];

		if ( languageFiles.length > 1 ) {
			return gulp.src( languageFiles )
				.pipe( concat( languageKey + '.po' ) )
				.pipe( gulp.dest( childThemePath + '/languages/compiled/' ) )
				.pipe( gulpPo2Mo() )
				.pipe( gulp.dest( childThemePath + '/languages/' ) );
		} else {
			return gulp.src( languageFiles )
				.pipe( gulp.dest( childThemePath + '/languages/compiled/' ) )
				.pipe( gulpPo2Mo() )
				.pipe( gulp.dest( childThemePath + '/languages/' ) );
		}
	} );

} );

gulp.task( 'assets:watch', function () {
	gulp.watch( [
		baseThemePath + '/resources/js/**/*.js', baseThemePath + '/modules/**/*.js',
		childThemePath + '/resources/js/**/*.js', childThemePath + '/modules/**/*.js',
		childThemePath + '/temporary-modules/**/*.js'
	], [ 'assets:js' ] );

	gulp.watch( [
		baseThemePath + '/resources/sass/**/*.scss', baseThemePath + '/modules/**/*.scss',
		childThemePath + '/resources/sass/**/*.scss', childThemePath + '/modules/**/*.scss',
		childThemePath + '/temporary-modules/**/*.scss'
	], [ 'assets:sass' ] );

	gulp.watch( [
		baseThemePath + '/modules/**/languages/**.po', childThemePath + '/languages/**.po',
		childThemePath + '/modules/**/languages/**.po',
		childThemePath + '/temporary-modules/**/languages/**.po'
	], [ 'languages' ] );
} );

gulp.task( 'assets', [ 'assets:js', 'assets:sass' ] );
gulp.task( 'watch', [ 'assets:watch' ] );
gulp.task( 'default', [ 'assets', 'languages', 'watch' ] );

function getBrowserCompatibility() {
	let browserCompatibility = [
		'>= 1%',
		'last 1 major version',
		'not dead',
		'Chrome >= 45',
		'Firefox >= 38',
		'Edge >= 12',
		'Explorer >= 10',
		'iOS >= 9',
		'Safari >= 9',
		'Android >= 4.4',
		'Opera >= 30'
	];

	try {
		let envBrowserCompatibility;

		if ( process.env.BROWSER_COMPATIBILITY && (envBrowserCompatibility =
			JSON.parse( process.env.BROWSER_COMPATIBILITY )) ) {
			browserCompatibility = envBrowserCompatibility;
		}
	} catch ( error ) {
	}

	return browserCompatibility;
}

function getThemeModules() {
	let activeModules = {},
		modulesConfigFile = childThemePath + '/modules.json',
		baseThemeModuleDir = baseThemePath + '/modules/',
		tempThemeModuleDir = childThemePath + '/temporary-modules/',
		childThemeModuleDir = childThemePath + '/modules/';

	if ( !fs.existsSync( modulesConfigFile ) ) {
		modulesConfigFile = baseThemePath + '/modules.json';
	}

	try {
		let modules = require( modulesConfigFile );

		Object.keys( modules ).forEach( module => {
			let moduleData = modules[module];

			if ( !!(moduleData.active || false) ) {
				activeModules[module] = moduleData;
				activeModules[module].paths = [];

				// Add the temporary module dir OR the base theme module dir, not both
				if ( fs.existsSync( tempThemeModuleDir + module ) ) {
					activeModules[module].paths.push( tempThemeModuleDir + module );
				} else if ( fs.existsSync( baseThemeModuleDir + module ) ) {
					activeModules[module].paths.push( baseThemeModuleDir + module );
				}

				// Add the child theme module dir if it exists
				if ( fs.existsSync( childThemeModuleDir + module ) ) {
					activeModules[module].paths.push( childThemeModuleDir + module );
				}
			}
		} );
	} catch ( error ) {
	}

	return activeModules;
}

/**
 * @description Scan directory for files
 *
 * @param {string} startPath Path of where to start search from
 * @param {string} filter
 * @param {boolean} recursive
 */
function searchDir( startPath, filter, recursive ) {
	if ( !fs.existsSync( startPath ) ) {
		return false;
	}

	let filesArray = [];
	const files = fs.readdirSync( startPath );

	for ( var i = 0; i < files.length; i++ ) {
		const filename = path.join( startPath, files[i] );
		var stat = fs.lstatSync( filename );

		if ( stat.isDirectory() && recursive === true ) {
			const filesRecursive = searchDir( filename, filter );
			filesArray = [ ...filesArray, ...filesRecursive ];
		} else if ( filename.indexOf( filter ) >= 0 ) {
			filesArray.push( filename );
		}
	}

	return filesArray;
}