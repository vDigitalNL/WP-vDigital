import BaseTheme from '../../../[base_theme_folder]/resources/js/theme/theme';

let theme = window.BaseTheme = window.BaseTheme || new BaseTheme();