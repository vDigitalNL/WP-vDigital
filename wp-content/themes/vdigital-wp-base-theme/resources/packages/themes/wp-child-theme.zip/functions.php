<?php
	if ( ! defined( 'DS' ) ) {
		define( 'DS', DIRECTORY_SEPARATOR );
	}

	//Define the base theme and child theme root
	define( 'WP_BASE_THEME_DIR_ROOT', get_template_directory() . DS );
	define( 'WP_CHILD_THEME_DIR_ROOT', get_stylesheet_directory() . DS );

	//Include the base theme and child theme constants
	require_once( WP_BASE_THEME_DIR_ROOT . 'inc/constants.php' );
	require_once( WP_CHILD_THEME_DIR_ROOT . 'inc/constants.php' );

	//Include the base theme and child theme autoloaders
	require_once( WP_BASE_THEME_DIR_INCLUDES . 'autoload.php' );
	require_once( WP_CHILD_THEME_DIR_INCLUDES . 'autoload.php' );


	/**
	 * @return \ChildTheme\ChildTheme
	 */
	function childTheme() {
		return \ChildTheme\ChildTheme::getInstance();
	}


	//Initialize the child theme framework
	childTheme()->init();