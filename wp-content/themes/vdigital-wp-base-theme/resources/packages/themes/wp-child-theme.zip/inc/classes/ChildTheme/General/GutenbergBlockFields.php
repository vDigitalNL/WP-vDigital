<?php

	namespace ChildTheme\ChildTheme\General;

	use ChildTheme\ChildTheme\AbstractClass;
	use Theme\BaseTheme\ThemeFlexClassTrait;

	/**
	 * Class GutenbergBlockFields
	 *
	 * @package ChildTheme\ChildTheme\General
	 */
	class GutenbergBlockFields extends AbstractClass {

		use ThemeFlexClassTrait;

		/**
		 * Init ACF admin fields for this module on post edit pages / option pages
		 */
		public function init() {
			if ( function_exists( 'acf_register_block' ) ) {
				add_action( 'acf/init', function () {
					//$this->[ClassName]->init();
				}, 25 );
			}
		}
	}