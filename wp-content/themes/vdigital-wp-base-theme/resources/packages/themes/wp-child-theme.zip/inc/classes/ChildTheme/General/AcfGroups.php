<?php

	namespace ChildTheme\ChildTheme\General;

	use ChildTheme\ChildTheme\AbstractClass;
	use Theme\BaseTheme\ThemeFlexClassTrait;

    /**
     * Class AcfGroups
     *
     * @package ChildTheme\ChildTheme\General
     */
    final class AcfGroups extends AbstractClass {

        use ThemeFlexClassTrait;

        public function init() {
	        // $this->[ClassName]->init();
        }
    }