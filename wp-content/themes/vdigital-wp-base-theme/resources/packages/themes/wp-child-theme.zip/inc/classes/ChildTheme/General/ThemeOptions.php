<?php

	namespace ChildTheme\ChildTheme\General;

	use Theme\BaseTheme;
	use Theme\BaseTheme\ThemeFlexClassTrait;

	/**
	 * Class ThemeOptions
	 *
	 * @package ChildTheme\ChildTheme\General
	 *
	 * @property-read ThemeOptions\Example $Example
	 * @property-read ThemeOptions\Footer  $Footer
	 */
	final class ThemeOptions extends BaseTheme\AbstractClass {

		use ThemeFlexClassTrait;

		public function init() {
			/*
			 * Extend BaseTheme tabs
			 */
			$this->Footer->init();


			/*
			 * Register new tabs
			 */
			$this->baseTheme->addAction( 'theme_options/after_registering_tabs', [ $this, 'registerTabs' ], 5 );
		}

		/**
		 * Initialize the theme options page fields
		 *
		 * @param string $optionGroupKey
		 */
		public function registerTabs( string $optionGroupKey ) {
			/*
			 * Example options file
			 */
			$this->Example->registerTab( $optionGroupKey );
		}
	}