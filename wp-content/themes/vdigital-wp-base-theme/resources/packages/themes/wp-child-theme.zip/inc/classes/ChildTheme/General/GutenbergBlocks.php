<?php

	namespace ChildTheme\ChildTheme\General;

	use ChildTheme\ChildTheme\AbstractClass;
	use Theme\BaseTheme\ThemeFlexClassTrait;

	/**
	 * Class GutenbergBlocks
	 *
	 * @package ChildTheme\ChildTheme\General
	 */
	class GutenbergBlocks extends AbstractClass {

		use ThemeFlexClassTrait;

		/**
		 * Init new Gutenberg blocks with classes within a folder "GutenbergBlocks"
		 */
		public function init() {
			if ( function_exists( 'acf_register_block' ) ) {
				add_action( 'acf/init', function () {
					//$this->[ClassName]->init();
				} );
			}
		}
	}