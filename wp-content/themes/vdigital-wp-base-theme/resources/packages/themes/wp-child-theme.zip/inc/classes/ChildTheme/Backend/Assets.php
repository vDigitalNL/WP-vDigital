<?php

	namespace ChildTheme\ChildTheme\Backend;

	use ChildTheme\ChildTheme\AbstractClass;

	/**
	 * Class Assets
	 *
	 * @package Theme\ChildTheme\ChildTheme\Backend
	 */
	final class Assets extends AbstractClass {

		/**
		 * Include theme css and js files
		 */
		public function init() {
		}
	}