<?php

	namespace ChildTheme\ChildTheme\General;

	use ChildTheme\ChildTheme\AbstractClass;

	/**
	 * Class AcfFields
	 *
	 * @package ChildTheme\ChildTheme\General
	 */
	final class AcfFields extends AbstractClass {

		/**
		 * Init new ACF fields with classes within a folder "AcfFields".
		 * They should extend the class \Theme\BaseTheme\General\AcfFields\AbstractAcfField.
		 */
		public function init() {
			add_action( 'acf/include_field_types', function () {
			} );
		}
	}