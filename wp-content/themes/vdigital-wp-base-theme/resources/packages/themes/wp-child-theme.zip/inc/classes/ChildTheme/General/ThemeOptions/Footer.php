<?php

	namespace ChildTheme\ChildTheme\General\ThemeOptions;

	use Theme\BaseTheme\AbstractClass;
	use Theme\BaseTheme\ThemeFlexClassTrait;

	/**
	 * Class Footer
	 *
	 * @package ChildTheme\ChildTheme\General\ThemeOptions
	 */
	final class Footer extends AbstractClass {

		use ThemeFlexClassTrait;

		public function init() {
			$this->baseTheme->addFilter( 'theme_options/footer/sub_fields', [ $this, 'addFields' ], 5, 2 );
		}

		/**
		 * @param array[] $fields
		 * @param string  $optionFieldKey
		 *
		 * @return array[]
		 */
		public function addFields( array $fields, string $optionFieldKey ): array {
			/*
			 * Add new fields to $fields
			 */

			return $fields;
		}
	}