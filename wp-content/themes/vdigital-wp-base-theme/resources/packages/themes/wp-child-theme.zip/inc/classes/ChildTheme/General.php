<?php

	namespace ChildTheme\ChildTheme;

	use ChildTheme\ChildTheme\General\ThemeOptions;
	use Theme\BaseTheme\ThemeFlexClassTrait;

	/**
	 * Class General
	 *
	 * @package ChildTheme\ChildTheme
	 *
	 * @property-read ThemeOptions $ThemeOptions
	 */
	final class General extends AbstractClass {

		use ThemeFlexClassTrait;

		public function init() {
			$this->ThemeOptions->init();
		}
	}