<?php

	namespace ChildTheme\ChildTheme\General\ThemeOptions;

	use Theme\BaseTheme\AbstractClass;
	use Theme\BaseTheme\General\ThemeOptions\ThemeOptionFieldsTrait;
	use Theme\BaseTheme\ThemeFlexClassTrait;

	/**
	 * Class Example
	 *
	 * @package ChildTheme\ChildTheme\General\ThemeOptions
	 */
	final class Example extends AbstractClass {

		use ThemeFlexClassTrait;
		use ThemeOptionFieldsTrait;

		/**
		 * @param string $optionGroupKey
		 */
		public function registerTab( string $optionGroupKey ) {
			$optionFieldKey = $optionGroupKey . '__example';

			/*$this->addTab( $this->baseTheme->__( 'Example' ), $optionGroupKey, $optionFieldKey )
				 ->addFields( $this->getFields(), $optionGroupKey, $optionFieldKey )
				 ->registerFields();*/
		}

		/**
		 * @return array[]
		 */
		private function getFields(): array {
			$fields = [];

			return $fields;
		}
	}