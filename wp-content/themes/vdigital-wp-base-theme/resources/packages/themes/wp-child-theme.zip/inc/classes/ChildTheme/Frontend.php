<?php

	namespace ChildTheme\ChildTheme;

	use Theme\BaseTheme\ThemeFlexClassTrait;

	/**
	 * Class Frontend
	 *
	 * @package ChildTheme\ChildTheme
	 *
	 * @property-read Frontend\Assets $Assets
	 */
	final class Frontend extends AbstractClass {

		use ThemeFlexClassTrait;

		public function init() {
			$this->Assets->init();
		}
	}