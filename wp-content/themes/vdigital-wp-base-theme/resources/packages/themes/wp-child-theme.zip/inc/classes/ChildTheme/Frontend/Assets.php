<?php

	namespace ChildTheme\ChildTheme\Frontend;

	use ChildTheme\ChildTheme\AbstractClass;

	/**
	 * Class Assets
	 *
	 * @package Theme\ChildTheme\ChildTheme\Frontend
	 */
	final class Assets extends AbstractClass {

		/**
		 * Enqueue frontend theme stylesheets and scripts
		 */
		public function enqueueAssets() {
			$cssFiles = [
				[
					'dependencies' => [],
					'handle'       => 'theme-example',
					'media'        => 'all',
					'source'       => $this->childTheme->themeRootDir() . '/assets/css/example.css',
					'url'          => $this->childTheme->themeRootUri() . '/assets/css/example.css',
				],
			];
			$jsFiles  = [
				/*[
					'dependencies' => [],
					'handle'       => 'theme-example',
					'in_footer'    => true,
					'source'       => $this->childTheme->themeRootDir() . '/assets/js/example.js',
					'url'          => $this->childTheme->themeRootUri() . '/assets/js/example.js',
				],*/
			];

			foreach ( $cssFiles as $cssFile ) {
				if ( is_readable( $cssFile['source'] ) ) {
					wp_enqueue_style( $cssFile['handle'], $cssFile['url'], $cssFile['dependencies'], filemtime( $cssFile['source'] ), $cssFile['media'] );
				}
			}

			foreach ( $jsFiles as $jsFile ) {
				if ( is_readable( $jsFile['source'] ) ) {
					wp_enqueue_script( $jsFile['handle'], $jsFile['url'], $jsFile['dependencies'], filemtime( $jsFile['source'] ), $jsFile['in_footer'] );
				}
			}
		}

		public function init() {
			add_action( 'wp_enqueue_scripts', [ $this, 'enqueueAssets' ], 12 );
		}
	}