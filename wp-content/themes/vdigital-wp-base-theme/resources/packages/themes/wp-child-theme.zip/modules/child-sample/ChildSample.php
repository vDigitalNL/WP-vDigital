<?php

	namespace ChildTheme\Modules;

	use ChildTheme\ChildTheme\ThemeModuleAbstractBaseClass;

	/**
	 * Class ChildSample
	 *
	 * @package ChildTheme\Modules
	 *
	 * @property-read ChildSample\General $General
	 */
	class ChildSample extends ThemeModuleAbstractBaseClass {

	}