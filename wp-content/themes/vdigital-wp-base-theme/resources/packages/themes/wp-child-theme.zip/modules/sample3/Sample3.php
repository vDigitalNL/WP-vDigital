<?php

	namespace ChildTheme\Modules;

	/**
	 * Class Sample3
	 *
	 * @package ChildTheme\Modules
	 */
	class Sample3 extends \Theme\Modules\Sample3 {

	}