/*console.log('child sample module loaded from child theme');*/
