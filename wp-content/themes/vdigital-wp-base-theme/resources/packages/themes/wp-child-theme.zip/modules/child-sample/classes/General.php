<?php

	namespace ChildTheme\Modules\ChildSample;

	use Theme\BaseTheme\ThemeModuleAbstractClass;
	use Theme\BaseTheme\ThemeFlexClassTrait;

	/**
	 * Class General
	 *
	 * @package ChildTheme\Modules\ChildSample
	 */
	class General extends ThemeModuleAbstractClass {

		use ThemeFlexClassTrait;

		public function init() {
		}
	}